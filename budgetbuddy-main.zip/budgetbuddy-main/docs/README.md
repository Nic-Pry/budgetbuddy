# BudgetBuddy

A small spending/allowance tracker you run in the terminal. Add transactions,
list them, and see your balance. This is your squad's starting product for
Elite 101 - you'll grow it one ticket at a time.

## Run it

```bash
python main.py
```

## Run the tests

```bash
python -m unittest
```

## How it's laid out

| File | What it does |
|---|---|
| `main.py` | The menu loop you interact with |
| `storage.py` | Loads and saves the JSON data file |
| `features/core.py` | The transactions, the balance, and small helpers |
| `features/reports.py` | Summary reports (half-built - finish it via a ticket) |
| `data/budgetbuddy.json` | The transaction history and starting balance |
| `tests/test_core.py` | Example tests to copy from |

## Team


<!-- Add yourself here on your Git lesson: - Your Name (role) -->
Saim Khalil
- (your squad will add themselves here)

## Where to start

Pick a ticket from the `tickets/` folder (or the Issues tab once your section
repo exists). Read `CONTRIBUTING.md` for the Definition of Done every pull
request has to meet.

## Version 1.0

Fixed account_sumamry crashing bug

Added 2 tests for average_balance

Fixed last_transaction and count_by_category bugs

Fixed total_spent and average_transaction bugs

Documented last_transaction

Added a new monthly summary option

Added developer name to team section